# RSA File Transfer App - Python with tkinter
import tkinter as tk
from tkinter import filedialog, messagebox
import rsa

class RSAFileApp:
    def __init__(self, root):
        self.root = root
        self.root.title("RSA File Transfer")
        self.root.geometry("500x300")
        self.public_key = None
        self.private_key = None

        # Widgets
        self.input_path = tk.StringVar()
        self.encrypted_path = tk.StringVar()

        tk.Label(root, text="Chọn file để mã hóa:").pack(pady=5)
        tk.Entry(root, textvariable=self.input_path, width=50).pack()
        tk.Button(root, text="Browse", command=self.browse_input).pack()

        tk.Button(root, text="Tạo khóa RSA", command=self.generate_keys).pack(pady=5)
        tk.Button(root, text="Mã hóa file", command=self.encrypt_file).pack(pady=5)

        tk.Label(root, text="Chọn file để giải mã:").pack(pady=5)
        tk.Entry(root, textvariable=self.encrypted_path, width=50).pack()
        tk.Button(root, text="Browse", command=self.browse_encrypted).pack()

        tk.Button(root, text="Giải mã file", command=self.decrypt_file).pack(pady=5)

    def browse_input(self):
        path = filedialog.askopenfilename()
        if path:
            self.input_path.set(path)

    def browse_encrypted(self):
        path = filedialog.askopenfilename()
        if path:
            self.encrypted_path.set(path)

    def generate_keys(self):
        (self.public_key, self.private_key) = rsa.newkeys(2048)
        with open("public.pem", "wb") as pub_file:
            pub_file.write(self.public_key.save_pkcs1())
        with open("private.pem", "wb") as priv_file:
            priv_file.write(self.private_key.save_pkcs1())
        messagebox.showinfo("Thông báo", "Đã tạo khóa RSA và lưu vào file")

    def encrypt_file(self):
        path = self.input_path.get()
        if not path:
            messagebox.showerror("Lỗi", "Vui lòng chọn file đầu vào")
            return
        with open(path, 'r') as f:
            data = f.read().encode('utf-8')
        with open("public.pem", "rb") as pub_file:
            pubkey = rsa.PublicKey.load_pkcs1(pub_file.read())
        encrypted = rsa.encrypt(data, pubkey)
        with open("encrypted.bin", "wb") as enc_file:
            enc_file.write(encrypted)
        messagebox.showinfo("Thành công", "Đã mã hóa file thành encrypted.bin")

    def decrypt_file(self):
        path = self.encrypted_path.get()
        if not path:
            messagebox.showerror("Lỗi", "Vui lòng chọn file mã hóa")
            return
        with open(path, 'rb') as f:
            encrypted = f.read()
        with open("private.pem", "rb") as priv_file:
            privkey = rsa.PrivateKey.load_pkcs1(priv_file.read())
        try:
            decrypted = rsa.decrypt(encrypted, privkey)
            with open("decrypted.txt", "w", encoding='utf-8') as dec_file:
                dec_file.write(decrypted.decode('utf-8'))
            messagebox.showinfo("Thành công", "Đã giải mã file thành decrypted.txt")
        except:
            messagebox.showerror("Lỗi", "Giải mã thất bại")

if __name__ == "__main__":
    root = tk.Tk()
    app = RSAFileApp(root)
    root.mainloop()
