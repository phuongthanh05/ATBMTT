from flask import Flask, render_template, request, send_from_directory
from rsa_utils import generate_keys, sign_data, verify_signature
from cryptography.hazmat.primitives import serialization
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def home():
    return "<h2>🔐 Hệ thống ký và xác minh</h2><a href='/sender'>Người gửi</a> | <a href='/receiver'>Người nhận</a>"

@app.route('/sender')
def sender_page():
    return render_template('sender.html')

@app.route('/receiver')
def receiver_page():
    return render_template('receiver.html')

@app.route('/sign', methods=['POST'])
def sign():
    file = request.files['file']
    filename = file.filename
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    file.save(filepath)

    with open(filepath, 'rb') as f:
        data_bytes = f.read()

    private_key_path = os.path.join(UPLOAD_FOLDER, "private_key.pem")
    public_key_path = os.path.join(UPLOAD_FOLDER, "public_key.pem")

    if not os.path.exists(private_key_path):
        private_key, public_key = generate_keys()
        with open(private_key_path, 'wb') as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ))
        with open(public_key_path, 'wb') as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ))
    else:
        with open(private_key_path, 'rb') as f:
            private_key = serialization.load_pem_private_key(f.read(), password=None)
        with open(public_key_path, 'rb') as f:
            public_key = serialization.load_pem_public_key(f.read())

    signature = sign_data(private_key, data_bytes)
    sig_path = os.path.join(UPLOAD_FOLDER, filename + '.sig')
    with open(sig_path, 'wb') as f:
        f.write(signature)

    return render_template('result_links.html', filename=filename)

@app.route('/verify', methods=['POST'])
def verify():
    file = request.files['file']
    sig = request.files['signature']
    pubkey = request.files['pubkey']

    data_bytes = file.read()
    signature = sig.read()
    public_key = serialization.load_pem_public_key(pubkey.read())

    result = verify_signature(public_key, data_bytes, signature)
    return f"<h2 style='color:{'green' if result else 'red'}'>Kết quả: {'Hợp lệ' if result else 'Không hợp lệ'}</h2><a href='/'>Quay lại</a>"

@app.route('/uploads/<path:filename>')
def download_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)

@app.route('/get_public_key')
def get_public_key():
    pubkey_path = os.path.join(UPLOAD_FOLDER, "public_key.pem")
    if os.path.exists(pubkey_path):
        return send_from_directory(UPLOAD_FOLDER, "public_key.pem", as_attachment=True)
    return "Khóa công khai chưa được tạo.", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
