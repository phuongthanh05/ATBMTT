
import socket
import os

RECEIVE_FOLDER = 'received'
os.makedirs(RECEIVE_FOLDER, exist_ok=True)

def start_receiver(host='0.0.0.0', port=6000):
    s = socket.socket()
    s.bind((host, port))
    s.listen(1)
    print(f"📥 Đang lắng nghe tại {host}:{port}...")

    conn, addr = s.accept()
    print(f"📨 Kết nối từ {addr}")

    filename = conn.recv(1024).decode()
    filepath = os.path.join(RECEIVE_FOLDER, filename)
    with open(filepath, 'wb') as f:
        print(f"📄 Đang nhận file: {filename}")
        while True:
            data = conn.recv(4096)
            if not data:
                break
            f.write(data)
    print(f"✅ File đã lưu tại: {filepath}")
    conn.close()

def send_file(filepath, host='127.0.0.1', port=6000):
    s = socket.socket()
    s.connect((host, port))

    filename = os.path.basename(filepath)
    s.send(filename.encode())

    with open(filepath, 'rb') as f:
        while chunk := f.read(4096):
            s.send(chunk)
    s.close()
    print(f"✅ Đã gửi file: {filename}")

if __name__ == '__main__':
    start_receiver()
